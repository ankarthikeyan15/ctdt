package com.example.karthikeyan.myapp;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;
import android.support.v7.view.ContextThemeWrapper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity {
    CheckBox door;
    CheckBox light;
    CheckBox fan;
    String d,l,f;
    TextView textView;
    Timer timer;
    MyTimerTask task;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        door = (CheckBox) findViewById(R.id.checkBox);
        light = (CheckBox) findViewById(R.id.checkBox2);
        fan = (CheckBox) findViewById(R.id.checkBox3);
        textView = (TextView) findViewById(R.id.textView2);
        textView.setText("Details!!!");
        timer = new Timer();
        task = new MyTimerTask();
        d = l = f = "0";
        timer.schedule(task,1000,2000);
        Intent intent = new Intent(this,MyService.class);
        startService(intent);
    }

    class  MyTimerTask extends TimerTask {

        @Override
        public void run() {
            String link = "http://192.168.116.64/check/getlast.php";
            URL url = null;
            try {
                url = new URL(link);
                URLConnection conn = null;
                conn = url.openConnection();
                String toSend = URLEncoder.encode("door","UTF-8") + "=" + URLEncoder.encode("door","UTF-8");
                conn.setDoOutput(true);
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(toSend);
                wr.flush();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line = null;
                while((line = reader.readLine())!= null)
                {
                    sb.append(line);
                    break;
                }
                String temp = sb.toString();
                ForStaticData.res = "Currently Open/On: ";
                if( temp.charAt(0) == '1')
                    ForStaticData.res += "Door ";
                if( temp.charAt(1) == '1')
                    ForStaticData.res += "Light ";
                if( temp.charAt(2) == '1')
                    ForStaticData.res += "Fan";
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            runOnUiThread(new Runnable(){

                @Override
                public void run() {
                    textView.setText(ForStaticData.res);
                }
            });
        }
    }

    public void createNotification(String s){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setContentTitle("DB Status");
        builder.setContentText("Rows:" + s);
        builder.setSmallIcon(R.drawable.ic_stat_name);

        Notification notification = builder.build();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(1, notification);
    }

    public void send(View view) {
        System.out.println("Came in Send");
        if(door.isChecked())
        {
            d = "1";
        }
        if(light.isChecked())
        {
            l = "1";
        }
        if(fan.isChecked())
        {
            f = "1";
        }
        new PostData(this).execute(d,l,f);
        d = l = f = "0";
        //if(ForStaticData.res!="0")
            //textView.setText(ForStaticData.res);
        end();
        //finish();
        //startActivity(getIntent());
    }
    public void end(){
        door.setChecked(false);
        light.setChecked(false);
        fan.setChecked(false);
    }
}

class ForStaticData {
    public static String res = "0";
    public static String cur = "0";
}

class PostData extends AsyncTask<String,String,String> {
    private Context context;
    public PostData(Context context){
        this.context = context;
    }
    @Override
    protected void onPreExecute(){

    }
    @Override
    protected String doInBackground(String... params) {
        try {
            String sdoor = (String)params[0];
            String slight = (String)params[1];
            String sfan = (String)params[2];
            String link = "http://192.168.116.64/check/create.php";
            String toSend = URLEncoder.encode("door","UTF-8") + "=" + URLEncoder.encode(sdoor,"UTF-8");
            toSend += "&" + URLEncoder.encode("light","UTF-8") + "=" + URLEncoder.encode(slight,"UTF-8");
            toSend += "&" + URLEncoder.encode("fan","UTF-8") + "=" + URLEncoder.encode(sfan,"UTF-8");
            URL url = new URL(link);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(toSend);
            wr.flush();
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;
            while((line = reader.readLine())!= null)
            {
                sb.append(line);
                break;
            }
            //ForStaticData.res = sb.toString();
            System.out.println("Received back" + sb.toString());
            return sb.toString();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    @Override
    protected void onPostExecute(String result){
        System.out.println("Success!!!");
    }
}
package com.example.karthikeyan.myapp;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v7.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Timer;
import java.util.TimerTask;

public class MyService extends Service {
    private static String cur ="0";
    private boolean isRunning;
    Timer timer2;
    MyTimerTask2 task2;

    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(MyService.this, "Service running",Toast.LENGTH_LONG).show();
        timer2 = new Timer();
        task2 = new MyTimerTask2();
        timer2.schedule(task2,1000,2000);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        Toast.makeText(MyService.this, "Service stopped",Toast.LENGTH_LONG).show();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void createNotification(){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setContentTitle("DB Status");
        builder.setContentText("DB changed!!!");
        builder.setSmallIcon(R.drawable.ic_stat_name);

        Notification notification = builder.build();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(1, notification);
    }

    class MyTimerTask2 extends TimerTask {
        String temp;
        @Override
        public void run() {
            String link = "http://192.168.116.64/check/getcount.php";
            URL url = null;
            try {
                url = new URL(link);
                URLConnection conn = null;
                conn = url.openConnection();
                String toSend = URLEncoder.encode("door","UTF-8") + "=" + URLEncoder.encode("door","UTF-8");
                conn.setDoOutput(true);
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
                wr.write(toSend);
                wr.flush();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line = null;
                while((line = reader.readLine())!= null)
                {
                    sb.append(line);
                    break;
                }
                temp = sb.toString();
                System.out.println("temp:" + temp);
                System.out.println("curr:" + ForStaticData.cur);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(!ForStaticData.cur.equals("0") && !ForStaticData.cur.equals(temp))
            {
                ForStaticData.cur = temp;
                createNotification();
            }
            if(ForStaticData.cur.equals("0"))
                ForStaticData.cur = temp;
        }
    }
}